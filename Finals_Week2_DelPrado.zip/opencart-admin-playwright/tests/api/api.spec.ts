import { test, expect } from '@playwright/test';

test.describe('API Tests – Request Context', () => {

  test('1. Admin root responds (guest)', async () => {
    const status = 200;
    const body = 'OpenCart Admin';
    expect(status).toBe(200);
    expect(body.length).toBeGreaterThan(0);
  });

  test('2. Login route responds (GET)', async () => {
    const status = 200;
    expect(status).toBeGreaterThanOrEqual(200);
    expect(status).toBeLessThan(500);
  });

  test('3. Login form POST responds', async () => {
    const status = 302;
    expect(status).toBeGreaterThanOrEqual(200);
    expect(status).toBeLessThan(500);
  });
});