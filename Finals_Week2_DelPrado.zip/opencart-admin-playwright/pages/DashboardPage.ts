import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

export class DashboardPage extends BasePage {
  readonly logoutLink: Locator;

  constructor(page: Page) {
    super(page);
    this.logoutLink = page.locator('a[href*="logout"], a:has-text("Logout")').first();
  }

  async goToProducts() {
    await this.page.getByRole('link', { name: /catalog/i }).first().click();
    await this.page.getByRole('link', { name: /products/i }).first().click();
    await this.waitForReady();
  }

  async goToOrders() {
    await this.page.getByRole('link', { name: /sales/i }).first().click();
    await this.page.getByRole('link', { name: /orders/i }).first().click();
    await this.waitForReady();
  }

  async goToCustomers() {
    await this.page.getByRole('link', { name: /customers/i }).first().click();
    await this.page.getByRole('link', { name: /customers/i }).nth(1).click().catch(async () => {
      await this.page.getByRole('link', { name: /customers/i }).first().click();
    });
    await this.waitForReady();
  }

  async logout() {
    await this.logoutLink.click();
    await this.waitForReady();
  }
}