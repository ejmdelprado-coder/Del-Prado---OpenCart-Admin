import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';

export class LoginPage extends BasePage {
  readonly username: Locator;
  readonly password: Locator;
  readonly loginBtn: Locator;

  constructor(page: Page) {
    super(page);
    this.username = page.locator('input[name="username"], #input-username').first();
    this.password = page.locator('input[name="password"], #input-password').first();
    this.loginBtn = page.locator('button[type="submit"], button:has-text("Login")').first();
  }

  async open() {
    await this.goto('/');
    await this.waitForReady();
  }

  async login(user: string, pass: string) {
    await this.username.fill(user);
    await this.password.fill(pass);
    await this.loginBtn.click();
    await this.waitForReady();
  }
}